#!/bin/sh

test -f /usr/share/acpi-support/key-constants || exit 0 
. /usr/share/acpi-support/key-constants
#acpi_fakekey $KEY_BRIGHTNESSDOWN

brightness=$( echo "$3" | sed 's/0000002//' )
setpci -s 00:02.0 F4.B=${brightness}f
