#!/bin/sh
test -f /usr/share/acpi-support/key-constants || exit 0

. /usr/share/acpi-support/key-constants

DeviceConfig

#if [ "$model" != "701" ] ; then
	# On an Eee PC (ASUSTeK model 701) the keys in the range handled by this
	# script have entirely different meanings. They are handled in separate
	# scripts.
#	acpi_fakekey $KEY_BRIGHTNESSUP
#fi

brightness=$( echo "$3" | sed 's/0000001//' )
echo "brn=$brightness 1=$1 2=$2 3=$3" >> "/home/vermind/Desktop/temp.txt"
setpci -s 00:02.0 F4.B=${brightness}f
